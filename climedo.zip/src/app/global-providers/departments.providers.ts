import {Injectable} from '@angular/core';
import {DepartmentContactModel, DepartmentInfoModel, DepartmentModel} from '../models/department.model';

@Injectable()
export class DepartmentsProviders {
  public departments: DepartmentModel[] = [];
  constructor () {}
  public saveDepartment (info: DepartmentInfoModel, contact: DepartmentContactModel) {
    return new Promise((resolve, reject) => {
      if (info instanceof DepartmentInfoModel && contact instanceof DepartmentContactModel) {
        this.departments.push(new DepartmentModel(info, contact));
        resolve(true);
      } else {
        reject(false);
      }
    });
  }
  public filterDepartments (value) {
    return this.departments.filter((department: DepartmentModel) => {
      const nameRegEx =  /^[A-Za-z]+$/;
      if (value.match(nameRegEx)) {
        if (department.info.name.toLowerCase().indexOf(value.toLowerCase()) > -1) {
          return department.info.name.toLowerCase().indexOf(value.toLowerCase()) > -1;
        } else if (department.contact.name.toLowerCase().indexOf(value.toLowerCase()) > -1) {
          return department.contact.name.toLowerCase().indexOf(value.toLowerCase()) > -1;
        }
      } else {
        return department.info.api.toLowerCase().indexOf(value.toLowerCase()) > -1;
      }
    });
  }
}
