import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {BehaviorSubject} from 'rxjs';
import {DepartmentsProviders} from '../../global-providers/departments.providers';
import {DepartmentContactModel, DepartmentInfoModel} from '../../models/department.model';

@Component({
  selector: 'app-create-dept',
  templateUrl: './create-department.component.html',
  styleUrls: ['./create-department.component.scss']
})

export class CreateDepartmentComponent implements OnInit {
  public deptInfo: FormGroup;
  public deptContact: FormGroup;
  public showForms = new BehaviorSubject<boolean>(false);
  public info: DepartmentInfoModel;
  public contact: DepartmentContactModel;
  constructor(private route: ActivatedRoute, private router: Router, private fb: FormBuilder, public service: DepartmentsProviders) {
  }
  ngOnInit () {
    this.deptInfo = this.fb.group({
      name: ['', [Validators.required]],
      api: ['', [Validators.required]]
    });
    this.deptContact = this.fb.group({
      name: ['', [Validators.required]],
      email: ['', [Validators.required]],
      tel: ['', [Validators.required]]
    });
    this.showForms.next(true);
  }
  public goToHome () {
    this.router.navigate([''], {relativeTo: this.route});
  }
  public async saveDepartment (info: FormGroup, contact: FormGroup) {
    this.info = new DepartmentInfoModel(info.controls['name'].value, info.controls['api'].value);
    this.contact = new DepartmentContactModel(
      contact.controls['name'].value,
      contact.controls['email'].value,
      contact.controls['tel'].value
    );
    try {
      const action = await this.service.saveDepartment(this.info, this.contact);
      this.router.navigate([''], {relativeTo: this.route});
    } catch (e) {
      console.log(e);
    }
  }
}
