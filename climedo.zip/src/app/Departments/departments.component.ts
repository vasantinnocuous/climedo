import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {DepartmentModel} from '../models/department.model';
import {DepartmentsProviders} from '../global-providers/departments.providers';
import {BehaviorSubject} from 'rxjs';
import {FormBuilder, FormGroup} from '@angular/forms';

@Component({
  selector: 'app-departments',
  templateUrl: './departments.component.html',
  styleUrls: ['./departments.component.scss']
})

export class DepartmentsComponent implements OnInit {
  public departments: DepartmentModel[] = [];
  public showCards = new BehaviorSubject<boolean>(false);
  public searchDepartment: FormGroup;
  constructor (private route: ActivatedRoute, private router: Router, private service: DepartmentsProviders, private fb: FormBuilder) {
    this.departments = this.service.departments;
  }
  ngOnInit () {
    this.searchDepartment = this.fb.group({
      searchInput: ['']
    });
    if (this.departments.length > 0) {
      this.showCards.next(true);
    }
    this.searchDepartment.get('searchInput').valueChanges.subscribe((value: string) => {
      this.departments = this.service.filterDepartments(value);
      console.log('search department is ', this.departments);
    });
  }
  public goToCreate () {
    this.router.navigate(['create'], {relativeTo: this.route});
  }
}
