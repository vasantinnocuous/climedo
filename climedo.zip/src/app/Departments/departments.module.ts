import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {DepartmentsComponent} from './departments.component';
import {RouterModule, Routes} from '@angular/router';
import {FontAwesomeModule} from '@fortawesome/angular-fontawesome';
import { library } from '@fortawesome/fontawesome-svg-core';
import { fas } from '@fortawesome/free-solid-svg-icons';
import { far } from '@fortawesome/free-regular-svg-icons';
import {CreateDepartmentComponent} from './create-department/create-department.component';
import {BsDropdownModule} from 'ngx-bootstrap/dropdown';

const routes: Routes = [
  {
    path: '',
    component: DepartmentsComponent,
  },
  {
    path: 'create',
    component: CreateDepartmentComponent
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    FontAwesomeModule,
    BsDropdownModule.forRoot(),
    RouterModule.forChild(routes)
  ],
  declarations: [
    DepartmentsComponent,
    CreateDepartmentComponent
  ]
})

export class DepartmentsModule {
  constructor () {
    library.add(fas, far);
  }
}
