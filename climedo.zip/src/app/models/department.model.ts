export class DepartmentModel {
  constructor(
    public info: DepartmentInfoModel,
    public contact: DepartmentContactModel
  ) {}
}

export class DepartmentInfoModel {
  constructor (
    public name: string,
    public api: string
  ) {}
}

export class DepartmentContactModel {
  constructor(
    public name: string,
    public email: string,
    public tel: number
  ) {}
}
